import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:pearlnest/blocs/new_chat_bloc/new_chat_bloc.dart';
import 'package:pearlnest/blocs/profile_bloc/profile_bloc.dart';
import 'package:pearlnest/blocs/shares/share_bloc.dart';
import 'package:pearlnest/blocs/views/views_bloc.dart';
import 'package:pearlnest/models/user.dart';
import 'package:pearlnest/models/user_type.dart';
import 'package:pearlnest/providers/notification_cubit.dart';
import 'package:pearlnest/services/new_chat_service.dart';
import 'package:pearlnest/services/profile_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'firebase_options.dart'; // Add this import
import 'package:pearlnest/apis/api_client.dart';
import 'package:pearlnest/widgets/theme_provider.dart';
import 'package:pearlnest/blocs/auth/auth_bloc.dart';
import 'package:pearlnest/blocs/auth/auth_state.dart';
import 'package:pearlnest/blocs/property/property_bloc.dart';
import 'package:pearlnest/blocs/property_upload/property_upload_bloc.dart';
import 'package:pearlnest/blocs/booking/booking_bloc.dart';
import 'package:pearlnest/blocs/chat/chat_bloc.dart';
import 'package:pearlnest/screens/common/splash_screen.dart';
import 'package:pearlnest/screens/tenant/home_screen.dart';
import 'package:pearlnest/widgets/app_theme.dart';
import 'package:pearlnest/widgets/permission_initialization_widget.dart';
import 'package:provider/provider.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:pearlnest/apis/booking_service.dart';
import 'package:pearlnest/services/deep_link_service.dart';
import 'package:pearlnest/services/notification_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Firebase with platform-specific options
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // Initialize notification service
  await NotificationService.initialize();

  // Load environment variables with error handling
  try {
    await dotenv.load(fileName: ".env");
  } catch (e) {
    //debugPrint('Warning: Could not load .env file: $e');
    // Continue without .env file - app should still work with default values
  }

  // Initialize API client
  await ApiClient.initialize();

  // Initialize deep link service
  DeepLinkService.initialize();

  //Initialize Shared preferences
  ProfileService().init();

  final prefs = await SharedPreferences.getInstance();
  final String? userId = prefs.getString('user_id');

  runApp(MyApp(
    userId: userId,
  ));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key, required this.userId});
  final String? userId;

  // Add a global navigator key
  static final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<AuthBloc>(
          create: (context) => AuthBloc(),
        ),
        BlocProvider<PropertyBloc>(
          create: (context) => PropertyBloc(),
        ),
        BlocProvider<PropertyUploadBloc>(
          create: (context) => PropertyUploadBloc(),
        ),
        BlocProvider<BookingBloc>(
          create: (context) => BookingBloc(bookingService: BookingService()),
        ),
        BlocProvider<ChatBloc>(
          create: (context) => ChatBloc(),
        ),
        BlocProvider<ProfileBloc>(
          create: (context) => ProfileBloc(),
        ),
        BlocProvider<ShareBloc>(
          create: (context) => ShareBloc(),
        ),
        BlocProvider<ViewsBloc>(
          create: (context) => ViewsBloc(),
        ),
        BlocProvider<NewChatBloc>(
          create: (context) => NewChatBloc(NewChatService(), userId ?? ""),
        ),
        BlocProvider(
          create: (context) => NotificationCubit()..initSocket(),
          child: MyApp(
            userId: userId,
          ),
        ),
      ],
      child: MultiProvider(
        providers: [
          ChangeNotifierProvider(create: (context) => ThemeProvider()),
        ],
        child: Consumer<ThemeProvider>(
          builder: (context, themeProvider, child) {
            return BlocListener<AuthBloc, AuthState>(
              listener: (context, state) {
                if (state is AuthSuccess) {
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    navigatorKey.currentState?.pushAndRemoveUntil(
                      MaterialPageRoute(
                        builder: (_) => HomeScreen(user: state.user),
                      ),
                      (route) => false,
                    );
                  });
                } else if (state is AuthLogOut) {
                  //Unknown user
                  final User user = User(
                    id: "",
                    name: "",
                    email: "",
                    phone: "",
                    userType: UserType.tenant,
                    createdAt: DateTime.now(),
                    updatedAt: DateTime.now(),
                  );

                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    navigatorKey.currentState?.pushAndRemoveUntil(
                      MaterialPageRoute(
                        builder: (_) => HomeScreen(user: user),
                      ),
                      (route) => false,
                    );
                  });
                }
              },
              child: MaterialApp(
                title: 'Pearl Nest Estates',
                theme: AppTheme.lightTheme,
                darkTheme: AppTheme.darkTheme,
                themeMode: themeProvider.themeMode,
                debugShowCheckedModeBanner: false,
                navigatorKey: navigatorKey, // Add the navigator key
                home: PermissionInitializationWidget(
                  child: _getInitialScreen(),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _getInitialScreen() {
    // Always start with SplashScreen - let each screen handle its own state management
    return const SplashScreen();
  }
}
